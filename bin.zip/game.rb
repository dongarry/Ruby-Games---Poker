require 'deck'

class Game
	include Card_funcs
	
	attr_reader :deck
	
	def initialize no_players=2
		@deck = Deck.new
		@no_of_players = no_players
	end
	
	def play_game  *test_hands 
			
		@no_of_players.times do |h|
			@deck.deal(test_hands[h].nil? ? [] : test_hands[h])
		end
			
		if @deck.check_deal 
			score_game 		
		else
			puts "Bad deal!"
		end
	end	
	
	def score_game 
		@deck.hands.sort!{|h1,h2| h1.score<=> h2.score}
		
		if @deck.hands[0].score==0
			@deck.hands.sort!{|h1,h2| h1.higest_cards[0]<=> h2.higest_cards[0]}			
		end

		puts "Winner : #{@deck.hands[0].hand}"

=begin		
		puts "score : #{h1.score<=>h2.score}"
		case h1.score<=>h2.score
			when 1
				puts "Hand 1 wins!"
			when -1
				puts "Hand 2 wins!"
			when 0
				5.times do |i| 
					if h1.highest_card[i] > h2.highest_card[i]
						puts "Hand 1 wins on #{i+1} highest card -> #{h1.highest_card[i]}"
						break
					elsif h2.highest_card[i] > h1.highest_card[i]
						puts "Hand 2 wins on #{i+1} highest card -> #{h2.highest_card[i]}"
						break
					end
				end
				
			else
				puts "This is a draw!"
		end
=end
	end
	
end

game = Game.new
game.play_game 
#game.play_game ['H2','C3','D12','H13','H14'], ['S2','H3','H4','C13','D14']


